/*
 avrdude executable usurpation used to load HEX in arduino based on USB chip such as 32U4 (leonardo, Pro Micro)
 These arduinos require an initial serial port open/close at 1200 baud to trig a reset in order to enter in bootloader mode.
  
 Usage:
 put regular avrdude in the same directory and rename it avrdude_
 This avrdude is invoked an the invokes the regular avrdude_.
 So that, avrdude GUI can be used with arduino based on USB chip such as 32U4 (leonardo, Pro Micro)
 
 In the same folder:
 avrdude_      The original avrdude (renamed avrdude_)
 avrdude       This executable extavrdude renamed in avrdude (same name as original avrdude)
 avrdude.conf  The avrdude configuration file
 
 RC Navy 2020
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <iostream>
#include <sys/ioctl.h>

#define DEBUG

using namespace std;

int main(int argc, char *argv[])
{
  const char *avrdude_ = "./avrdude_";
  char *PortName = NULL;
  int   Is32U4 = 0;
  char  CmdLine[1024] = {0};
  int RTS_flag, DTR_flag;
  int fd;
  int retSystem;
  struct termios termAttr;
  
  strcpy(CmdLine, avrdude_);
  for(int Idx = 0; Idx < argc; Idx++)
  {
    if(Idx) strcat(CmdLine, argv[Idx]);
    if(Idx < (argc - 1)) strcat(CmdLine, " ");
    if(!memcmp(argv[Idx], "-P", 2) && (strlen(argv[Idx]) >= 5))
    {
      PortName = &argv[Idx][2];
#ifdef DEBUG
      cout << "Port=" << PortName << endl;
#endif
    }
    if(!strcmp(argv[Idx], "-pm32u4") || !strcmp(argv[Idx], "-patmega32u4"))
    {
      Is32U4 = 1;
#ifdef DEBUG
      cout << "32U4 AVR" << endl;
#endif
    }
  }
  if(Is32U4 && PortName)
  {
    //open serial at 1200 bauds and close it to reset the AVR
    fd = open(PortName, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1)
    {
      perror("open_port: Unable to open serial port\n");
//      exit(1);
    }
#ifdef DEBUG
    cout << "Open Serial " << PortName << " at 1200 bauds..." << endl;
#endif
    //set baud to 1200 to reset Arduino Leonardo
    tcgetattr(fd,&termAttr);
    cfsetispeed(&termAttr,B1200);
    cfsetospeed(&termAttr,B1200);
    tcsetattr(fd,TCSANOW,&termAttr);

    RTS_flag = TIOCM_RTS;
    DTR_flag = TIOCM_DTR;
    ioctl(fd,TIOCMBIS,&RTS_flag);//Set RTS pin
    ioctl(fd,TIOCMBIC,&DTR_flag);//Clear DTR pin

    close(fd);
    cout << "Resetting AVR...." << endl;

    //delay 2 seconds after reseting
    sleep(2);
  }

  cout << "avrdude cmd: " << CmdLine << endl;
  retSystem = system(CmdLine);

  exit(retSystem);
  return(retSystem);
}
